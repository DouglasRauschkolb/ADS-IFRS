import React from "react";
import ContactView from "./Components/ContactView";
function App() {
    return (
        <div>
            <ContactView />
        </div>
    );
}
export default App;